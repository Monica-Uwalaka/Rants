# Rants
